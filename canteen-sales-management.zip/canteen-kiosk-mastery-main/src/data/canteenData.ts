
export interface MenuItem {
  id: number;
  name: string;
  price: number;
  category: string;
  cost: number;  // Cost to make the item (for profit calculations)
  inStock: boolean;
}

export interface Employee {
  id: string;
  name: string;
  role: string;
  salary: number;
  joinDate: string;
  contact: string;
}

export interface Sale {
  id: string;
  items: {
    menuItemId: number;
    quantity: number;
    price: number;
  }[];
  total: number;
  timestamp: string;
  cashierId: string;
}

export interface InventoryItem {
  id: number;
  name: string;
  quantity: number;
  unit: string;
  costPerUnit: number;
  lastRestocked: string;
}

// Populate menu items from the canteen report image
export const menuItems: MenuItem[] = [
  { id: 1, name: "Good day (Rs.5)", price: 5, category: "Snacks", cost: 4, inStock: true },
  { id: 2, name: "Good day (Rs.10)", price: 10, category: "Snacks", cost: 8, inStock: true },
  { id: 3, name: "Cool Drinks (Rs.20)", price: 20, category: "Beverages", cost: 15, inStock: true },
  { id: 4, name: "Milk Shake (Rs.35)", price: 35, category: "Beverages", cost: 25, inStock: true },
  { id: 5, name: "Slice Tera (Rs.10)", price: 10, category: "Snacks", cost: 7, inStock: true },
  { id: 6, name: "50/50 (Rs.10)", price: 10, category: "Snacks", cost: 7, inStock: true },
  { id: 7, name: "Bourbon (Rs.10)", price: 10, category: "Snacks", cost: 7, inStock: true },
  { id: 8, name: "Kalkona (Rs.1)", price: 1, category: "Snacks", cost: 0.5, inStock: true },
  { id: 9, name: "Kopiko (Rs.1)", price: 1, category: "Snacks", cost: 0.5, inStock: true },
  { id: 10, name: "Ural Metai (Rs.1)", price: 1, category: "Snacks", cost: 0.5, inStock: true },
  { id: 11, name: "Kadala Metai (Rs.5)", price: 5, category: "Snacks", cost: 3, inStock: true },
  { id: 12, name: "Ellu Metai (Rs.5)", price: 5, category: "Snacks", cost: 3, inStock: true },
  { id: 13, name: "Muruku (Rs.13)", price: 13, category: "Snacks", cost: 9, inStock: true },
  { id: 14, name: "Munch (Rs.5)", price: 5, category: "Snacks", cost: 3, inStock: true },
  { id: 15, name: "Dairy Milk (Rs.5)", price: 5, category: "Snacks", cost: 3, inStock: true },
  { id: 16, name: "Dairy Milk (Rs.10)", price: 10, category: "Snacks", cost: 7, inStock: true },
  { id: 17, name: "Manila (Rs.5)", price: 5, category: "Snacks", cost: 3, inStock: true },
  { id: 18, name: "Kadala Metai (Rs.10)", price: 10, category: "Snacks", cost: 7, inStock: true },
  { id: 19, name: "Chicken Meals (Rs.90)", price: 90, category: "Meals", cost: 70, inStock: true },
  { id: 20, name: "Fish Meals (Rs.90)", price: 90, category: "Meals", cost: 70, inStock: true },
  { id: 21, name: "Veg Meals (Rs.80)", price: 80, category: "Meals", cost: 60, inStock: true },
  { id: 22, name: "Ulunthu Vadai (Rs.8)", price: 8, category: "Snacks", cost: 5, inStock: true },
  { id: 23, name: "Vadai (Rs.8)", price: 8, category: "Snacks", cost: 5, inStock: true },
  { id: 24, name: "Onion Bonda (Rs.8)", price: 8, category: "Snacks", cost: 5, inStock: true },
  { id: 25, name: "Kadalai Urundai (Rs.5)", price: 5, category: "Snacks", cost: 3, inStock: true },
  { id: 26, name: "Paniyaram (Rs.7)", price: 7, category: "Snacks", cost: 4, inStock: true },
  { id: 27, name: "Omelet (Rs.12)", price: 12, category: "Snacks", cost: 8, inStock: true },
  { id: 28, name: "Lemon Juice (Rs.15)", price: 15, category: "Beverages", cost: 10, inStock: true },
  { id: 29, name: "Tea (Rs.8)", price: 8, category: "Beverages", cost: 5, inStock: true },
  { id: 30, name: "Coffee (Rs.10)", price: 10, category: "Beverages", cost: 6, inStock: true },
  { id: 31, name: "Poori Set (Rs.30)", price: 30, category: "Breakfast", cost: 20, inStock: true },
  { id: 32, name: "Ice (Rs.40)", price: 40, category: "Beverages", cost: 25, inStock: true },
  { id: 33, name: "Ice (Rs.30)", price: 30, category: "Beverages", cost: 20, inStock: true },
  { id: 34, name: "Ice (Rs.20)", price: 20, category: "Beverages", cost: 12, inStock: true },
  { id: 35, name: "Ice (Cone) (Rs.20)", price: 20, category: "Beverages", cost: 12, inStock: true },
  { id: 36, name: "Ice (Rs.10)", price: 10, category: "Beverages", cost: 6, inStock: true },
  { id: 37, name: "Pongal (Rs.30)", price: 30, category: "Breakfast", cost: 20, inStock: true },
  { id: 38, name: "Sarbath (Rs.15)", price: 15, category: "Beverages", cost: 10, inStock: true },
  { id: 39, name: "Butter Milk (Rs.10)", price: 10, category: "Beverages", cost: 6, inStock: true },
  { id: 40, name: "Curd (Rs.10)", price: 10, category: "Snacks", cost: 6, inStock: true },
  { id: 41, name: "Egg Bonda (Rs.10)", price: 10, category: "Snacks", cost: 7, inStock: true },
  { id: 42, name: "Veg Noodles (Rs.60)", price: 60, category: "Meals", cost: 40, inStock: true },
  { id: 43, name: "Egg Noodles (Rs.70)", price: 70, category: "Meals", cost: 45, inStock: true },
  { id: 44, name: "Upma Pachadi (Rs.30)", price: 30, category: "Breakfast", cost: 20, inStock: true },
  { id: 45, name: "Dosa 1 Set (Rs.25)", price: 25, category: "Breakfast", cost: 15, inStock: true },
  { id: 46, name: "Bajji (Rs.8)", price: 8, category: "Snacks", cost: 5, inStock: true },
  { id: 47, name: "5 Star (Rs.5)", price: 5, category: "Snacks", cost: 3, inStock: true },
  { id: 48, name: "Gems (Rs.5)", price: 5, category: "Snacks", cost: 3, inStock: true },
  { id: 49, name: "Masala Kadalai (Rs.13)", price: 13, category: "Snacks", cost: 8, inStock: true },
];

// Mock employees data
export const employees: Employee[] = [
  {
    id: "emp001",
    name: "Rajesh Kumar",
    role: "Cashier",
    salary: 15000,
    joinDate: "2022-03-15",
    contact: "9876543210",
  },
  {
    id: "emp002",
    name: "Priya Sharma",
    role: "Cook",
    salary: 18000,
    joinDate: "2021-11-10",
    contact: "8765432109",
  },
  {
    id: "emp003",
    name: "Vikram Singh",
    role: "Manager",
    salary: 25000,
    joinDate: "2020-08-22",
    contact: "7654321098",
  },
  {
    id: "emp004",
    name: "Lakshmi Narayanan",
    role: "Helper",
    salary: 12000,
    joinDate: "2023-01-05",
    contact: "6543210987",
  },
  {
    id: "emp005",
    name: "Mohammed Ismail",
    role: "Cashier",
    salary: 15000,
    joinDate: "2022-06-18",
    contact: "5432109876",
  },
];

// Mock inventory data
export const inventoryItems: InventoryItem[] = [
  {
    id: 1,
    name: "Rice",
    quantity: 50,
    unit: "kg",
    costPerUnit: 60,
    lastRestocked: "2023-04-01",
  },
  {
    id: 2,
    name: "Wheat Flour",
    quantity: 25,
    unit: "kg",
    costPerUnit: 45,
    lastRestocked: "2023-04-05",
  },
  {
    id: 3,
    name: "Cooking Oil",
    quantity: 30,
    unit: "liter",
    costPerUnit: 120,
    lastRestocked: "2023-04-02",
  },
  {
    id: 4,
    name: "Sugar",
    quantity: 20,
    unit: "kg",
    costPerUnit: 40,
    lastRestocked: "2023-04-03",
  },
  {
    id: 5,
    name: "Milk",
    quantity: 40,
    unit: "liter",
    costPerUnit: 60,
    lastRestocked: "2023-04-10",
  },
  {
    id: 6,
    name: "Tea Powder",
    quantity: 5,
    unit: "kg",
    costPerUnit: 300,
    lastRestocked: "2023-04-05",
  },
  {
    id: 7,
    name: "Coffee Powder",
    quantity: 3,
    unit: "kg",
    costPerUnit: 500,
    lastRestocked: "2023-04-05",
  },
  {
    id: 8,
    name: "Lentils",
    quantity: 15,
    unit: "kg",
    costPerUnit: 120,
    lastRestocked: "2023-04-04",
  },
  {
    id: 9,
    name: "Chicken",
    quantity: 25,
    unit: "kg",
    costPerUnit: 220,
    lastRestocked: "2023-04-10",
  },
  {
    id: 10,
    name: "Vegetables",
    quantity: 40,
    unit: "kg",
    costPerUnit: 60,
    lastRestocked: "2023-04-10",
  },
];

// Generate mock sales data
export const generateMockSales = (days: number): Sale[] => {
  const sales: Sale[] = [];
  const today = new Date();
  
  for (let i = 0; i < days; i++) {
    const date = new Date(today);
    date.setDate(date.getDate() - i);
    
    // Generate random number of sales for the day (5-15)
    const salesPerDay = Math.floor(Math.random() * 10) + 5;
    
    for (let j = 0; j < salesPerDay; j++) {
      // Random time during the day
      const hours = Math.floor(Math.random() * 9) + 8; // 8 AM to 5 PM
      const minutes = Math.floor(Math.random() * 60);
      date.setHours(hours, minutes);
      
      // Random number of items per sale (1-5)
      const itemCount = Math.floor(Math.random() * 5) + 1;
      const saleItems = [];
      let total = 0;
      
      for (let k = 0; k < itemCount; k++) {
        // Pick a random menu item
        const randomItemIndex = Math.floor(Math.random() * menuItems.length);
        const menuItem = menuItems[randomItemIndex];
        
        // Random quantity (1-3)
        const quantity = Math.floor(Math.random() * 3) + 1;
        
        saleItems.push({
          menuItemId: menuItem.id,
          quantity,
          price: menuItem.price
        });
        
        total += menuItem.price * quantity;
      }
      
      // Random cashier
      const cashierId = Math.random() > 0.5 ? "emp001" : "emp005";
      
      sales.push({
        id: `SALE-${date.toISOString().slice(0, 10)}-${j}`,
        items: saleItems,
        total,
        timestamp: date.toISOString(),
        cashierId
      });
    }
  }
  
  // Sort by timestamp (newest first)
  return sales.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
};

// Mock sales data for 30 days
export const mockSales = generateMockSales(30);

// Helper function to get sales for a specific date
export const getSalesForDate = (date: string): Sale[] => {
  const dateOnly = date.split('T')[0];
  return mockSales.filter(sale => sale.timestamp.includes(dateOnly));
};

// Helper function to get sales for a date range
export const getSalesForDateRange = (startDate: string, endDate: string): Sale[] => {
  const start = new Date(startDate).getTime();
  const end = new Date(endDate).getTime();
  
  return mockSales.filter(sale => {
    const saleTime = new Date(sale.timestamp).getTime();
    return saleTime >= start && saleTime <= end;
  });
};

// Helper function to calculate profit for a given sale
export const calculateSaleProfit = (sale: Sale): number => {
  let profit = 0;
  
  for (const saleItem of sale.items) {
    const menuItem = menuItems.find(item => item.id === saleItem.menuItemId);
    if (menuItem) {
      const revenue = saleItem.price * saleItem.quantity;
      const cost = menuItem.cost * saleItem.quantity;
      profit += revenue - cost;
    }
  }
  
  return profit;
};

// Helper to get total sales, revenue, and profit for a period
export const getSalesStats = (sales: Sale[]) => {
  const totalSales = sales.length;
  const totalRevenue = sales.reduce((sum, sale) => sum + sale.total, 0);
  const totalProfit = sales.reduce((sum, sale) => sum + calculateSaleProfit(sale), 0);
  
  return { totalSales, totalRevenue, totalProfit };
};

// Get total expenses (fixed costs) - simplified for demo
export const getTotalExpenses = (days: number): number => {
  // Daily fixed costs (rent, utilities, staff salaries)
  const dailyFixedCost = 2000; // Simplified for demo
  return dailyFixedCost * days;
};
