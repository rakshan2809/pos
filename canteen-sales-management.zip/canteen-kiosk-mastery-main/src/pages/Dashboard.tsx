
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import { 
  TrendingUp, 
  ShoppingCart, 
  CreditCard, 
  DollarSign,
  Calendar
} from 'lucide-react';
import { mockSales, getSalesForDate, getSalesStats, menuItems } from '@/data/canteenData';
import { useAuth } from '@/contexts/AuthContext';

// Colors for pie chart
const COLORS = ['#F97316', '#3B82F6', '#FBBF24', '#10B981', '#6366F1', '#EC4899'];

const Dashboard = () => {
  const { user } = useAuth();
  const [timeframe, setTimeframe] = useState('today');
  const [stats, setStats] = useState({ totalSales: 0, totalRevenue: 0, totalProfit: 0 });
  const [topSellingItems, setTopSellingItems] = useState<{ name: string; value: number }[]>([]);
  const [salesByCategory, setSalesByCategory] = useState<{ name: string; value: number }[]>([]);

  useEffect(() => {
    // Get date for timeframe
    const today = new Date();
    let startDate: Date;
    let endDate = new Date(today);
    endDate.setHours(23, 59, 59, 999);
    
    switch (timeframe) {
      case 'today':
        startDate = new Date(today);
        startDate.setHours(0, 0, 0, 0);
        break;
      case 'week':
        startDate = new Date(today);
        startDate.setDate(today.getDate() - 7);
        break;
      case 'month':
        startDate = new Date(today);
        startDate.setMonth(today.getMonth() - 1);
        break;
      default:
        startDate = new Date(today);
        startDate.setHours(0, 0, 0, 0);
        break;
    }
    
    // Filter sales for the timeframe
    const filteredSales = mockSales.filter(sale => {
      const saleDate = new Date(sale.timestamp);
      return saleDate >= startDate && saleDate <= endDate;
    });
    
    // Calculate stats
    const { totalSales, totalRevenue, totalProfit } = getSalesStats(filteredSales);
    setStats({ totalSales, totalRevenue, totalProfit });
    
    // Calculate top selling items
    const itemCounts: Record<number, number> = {};
    filteredSales.forEach(sale => {
      sale.items.forEach(item => {
        if (itemCounts[item.menuItemId]) {
          itemCounts[item.menuItemId] += item.quantity;
        } else {
          itemCounts[item.menuItemId] = item.quantity;
        }
      });
    });
    
    const topItems = Object.entries(itemCounts)
      .map(([id, count]) => {
        const menuItem = menuItems.find(item => item.id === Number(id));
        return {
          name: menuItem ? menuItem.name : `Item #${id}`,
          value: count
        };
      })
      .sort((a, b) => b.value - a.value)
      .slice(0, 5);
    
    setTopSellingItems(topItems);
    
    // Calculate sales by category
    const categorySales: Record<string, number> = {};
    filteredSales.forEach(sale => {
      sale.items.forEach(item => {
        const menuItem = menuItems.find(i => i.id === item.menuItemId);
        if (menuItem) {
          if (categorySales[menuItem.category]) {
            categorySales[menuItem.category] += item.price * item.quantity;
          } else {
            categorySales[menuItem.category] = item.price * item.quantity;
          }
        }
      });
    });
    
    const categoryData = Object.entries(categorySales)
      .map(([category, amount]) => ({
        name: category,
        value: amount
      }))
      .sort((a, b) => b.value - a.value);
    
    setSalesByCategory(categoryData);
  }, [timeframe]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
        <div className="flex items-center mt-4 md:mt-0">
          <Calendar className="mr-2 h-4 w-4 text-gray-500" />
          <Tabs value={timeframe} onValueChange={setTimeframe}>
            <TabsList>
              <TabsTrigger value="today">Today</TabsTrigger>
              <TabsTrigger value="week">This Week</TabsTrigger>
              <TabsTrigger value="month">This Month</TabsTrigger>
            </TabsList>
          </Tabs>
        </div>
      </div>
      
      {/* Overview stats */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Sales</CardTitle>
            <ShoppingCart className="h-4 w-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats.totalSales}</div>
            <p className="text-xs text-gray-500">Transactions</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
            <CreditCard className="h-4 w-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹{stats.totalRevenue.toFixed(2)}</div>
            <p className="text-xs text-gray-500">+{(stats.totalRevenue * 0.05).toFixed(2)} from last period</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Profit</CardTitle>
            <DollarSign className="h-4 w-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹{stats.totalProfit.toFixed(2)}</div>
            <p className="text-xs text-gray-500">
              <span className="text-green-500 inline-flex items-center">
                <TrendingUp className="mr-1 h-3 w-3" />
                {((stats.totalProfit / stats.totalRevenue) * 100).toFixed(1)}%
              </span> margin
            </p>
          </CardContent>
        </Card>
      </div>
      
      {/* Charts */}
      <div className="grid gap-4 md:grid-cols-2">
        {/* Top Selling Items */}
        <Card>
          <CardHeader>
            <CardTitle>Top Selling Items</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart
                  data={topSellingItems}
                  layout="vertical"
                  margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                >
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis type="number" />
                  <YAxis type="category" dataKey="name" width={150} />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="value" fill="#F97316" name="Quantity Sold" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
        
        {/* Category Sales */}
        <Card>
          <CardHeader>
            <CardTitle>Sales by Category</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-[300px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={salesByCategory}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    outerRadius={100}
                    fill="#8884d8"
                    dataKey="value"
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  >
                    {salesByCategory.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip formatter={(value) => `₹${value}`} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Dashboard;
