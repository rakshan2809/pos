
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { 
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { Search, Package, Plus, AlertTriangle } from 'lucide-react';
import { inventoryItems as initialInventoryItems, InventoryItem } from '@/data/canteenData';

const Inventory = () => {
  const [inventoryItems, setInventoryItems] = useState<InventoryItem[]>(initialInventoryItems);
  const [searchTerm, setSearchTerm] = useState('');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isUpdateDialogOpen, setIsUpdateDialogOpen] = useState(false);
  const [selectedItem, setSelectedItem] = useState<InventoryItem | null>(null);
  const [newItem, setNewItem] = useState<Partial<InventoryItem>>({
    name: '',
    quantity: 0,
    unit: '',
    costPerUnit: 0,
    lastRestocked: new Date().toISOString().split('T')[0]
  });
  
  // Filter inventory items based on search term
  const filteredItems = inventoryItems.filter(item =>
    item.name.toLowerCase().includes(searchTerm.toLowerCase())
  );
  
  // Add new inventory item
  const handleAddItem = () => {
    if (!newItem.name || !newItem.unit) {
      toast.error('Please fill out all required fields');
      return;
    }
    
    const newId = Math.max(...inventoryItems.map(item => item.id), 0) + 1;
    
    const itemToAdd: InventoryItem = {
      id: newId,
      name: newItem.name || '',
      quantity: newItem.quantity || 0,
      unit: newItem.unit || '',
      costPerUnit: newItem.costPerUnit || 0,
      lastRestocked: newItem.lastRestocked || new Date().toISOString().split('T')[0]
    };
    
    setInventoryItems([...inventoryItems, itemToAdd]);
    
    // Reset form and close dialog
    setNewItem({
      name: '',
      quantity: 0,
      unit: '',
      costPerUnit: 0,
      lastRestocked: new Date().toISOString().split('T')[0]
    });
    setIsAddDialogOpen(false);
    
    toast.success(`Added ${itemToAdd.name} to inventory`);
  };
  
  // Update inventory item
  const handleUpdateItem = () => {
    if (!selectedItem) return;
    
    setInventoryItems(prevItems =>
      prevItems.map(item =>
        item.id === selectedItem.id ? selectedItem : item
      )
    );
    
    setIsUpdateDialogOpen(false);
    toast.success(`Updated ${selectedItem.name} inventory`);
  };
  
  // Open update dialog for an item
  const openUpdateDialog = (item: InventoryItem) => {
    setSelectedItem(item);
    setIsUpdateDialogOpen(true);
  };
  
  // Get item stock status
  const getStockStatus = (quantity: number): 'low' | 'medium' | 'good' => {
    if (quantity <= 5) return 'low';
    if (quantity <= 15) return 'medium';
    return 'good';
  };
  
  // Get badge color based on stock status
  const getStockBadgeVariant = (status: 'low' | 'medium' | 'good') => {
    switch (status) {
      case 'low':
        return 'destructive';
      case 'medium':
        return 'default';
      case 'good':
        return 'secondary';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Inventory</h1>
          <p className="text-gray-500">Manage inventory items and stock levels</p>
        </div>
        
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Item
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Add Inventory Item</DialogTitle>
              <DialogDescription>
                Add a new item to your inventory. Click save when you're done.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="name" className="text-right">Name</Label>
                <Input
                  id="name"
                  value={newItem.name}
                  onChange={(e) => setNewItem({ ...newItem, name: e.target.value })}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="quantity" className="text-right">Quantity</Label>
                <Input
                  id="quantity"
                  type="number"
                  value={newItem.quantity}
                  onChange={(e) => setNewItem({ ...newItem, quantity: Number(e.target.value) })}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="unit" className="text-right">Unit</Label>
                <Input
                  id="unit"
                  value={newItem.unit}
                  onChange={(e) => setNewItem({ ...newItem, unit: e.target.value })}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="costPerUnit" className="text-right">Cost Per Unit</Label>
                <Input
                  id="costPerUnit"
                  type="number"
                  value={newItem.costPerUnit}
                  onChange={(e) => setNewItem({ ...newItem, costPerUnit: Number(e.target.value) })}
                  className="col-span-3"
                />
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>Cancel</Button>
              <Button onClick={handleAddItem}>Save</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
      
      {/* Search and filter */}
      <div className="flex gap-4">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
          <Input
            type="search"
            placeholder="Search inventory..."
            className="pl-8"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>
      
      {/* Inventory table */}
      <div className="border rounded-lg overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[50px]">#</TableHead>
              <TableHead>Name</TableHead>
              <TableHead>Quantity</TableHead>
              <TableHead>Unit</TableHead>
              <TableHead>Cost Per Unit</TableHead>
              <TableHead>Total Value</TableHead>
              <TableHead>Last Restocked</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredItems.map((item) => {
              const stockStatus = getStockStatus(item.quantity);
              
              return (
                <TableRow key={item.id}>
                  <TableCell>{item.id}</TableCell>
                  <TableCell className="font-medium">{item.name}</TableCell>
                  <TableCell>{item.quantity}</TableCell>
                  <TableCell>{item.unit}</TableCell>
                  <TableCell>₹{item.costPerUnit.toFixed(2)}</TableCell>
                  <TableCell>₹{(item.quantity * item.costPerUnit).toFixed(2)}</TableCell>
                  <TableCell>{new Date(item.lastRestocked).toLocaleDateString()}</TableCell>
                  <TableCell>
                    <Badge variant={getStockBadgeVariant(stockStatus)}>
                      {stockStatus === 'low' && <AlertTriangle className="mr-1 h-3 w-3" />}
                      {stockStatus.charAt(0).toUpperCase() + stockStatus.slice(1)}
                    </Badge>
                  </TableCell>
                  <TableCell className="text-right">
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={() => openUpdateDialog(item)}
                    >
                      Update
                    </Button>
                  </TableCell>
                </TableRow>
              );
            })}
            
            {filteredItems.length === 0 && (
              <TableRow>
                <TableCell colSpan={9} className="text-center h-24">
                  <div className="flex flex-col items-center justify-center text-gray-500">
                    <Package className="h-8 w-8 mb-2" />
                    <p>No inventory items found</p>
                  </div>
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
      
      {/* Update inventory dialog */}
      <Dialog open={isUpdateDialogOpen} onOpenChange={setIsUpdateDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Update Inventory</DialogTitle>
            <DialogDescription>
              Update the quantity and cost for this inventory item.
            </DialogDescription>
          </DialogHeader>
          {selectedItem && (
            <div className="grid gap-4 py-4">
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="update-name" className="text-right">Name</Label>
                <Input
                  id="update-name"
                  value={selectedItem.name}
                  onChange={(e) => setSelectedItem({ ...selectedItem, name: e.target.value })}
                  className="col-span-3"
                  disabled
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="update-quantity" className="text-right">Quantity</Label>
                <Input
                  id="update-quantity"
                  type="number"
                  value={selectedItem.quantity}
                  onChange={(e) => setSelectedItem({ ...selectedItem, quantity: Number(e.target.value) })}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="update-cost" className="text-right">Cost Per Unit</Label>
                <Input
                  id="update-cost"
                  type="number"
                  value={selectedItem.costPerUnit}
                  onChange={(e) => setSelectedItem({ ...selectedItem, costPerUnit: Number(e.target.value) })}
                  className="col-span-3"
                />
              </div>
              <div className="grid grid-cols-4 items-center gap-4">
                <Label htmlFor="update-date" className="text-right">Restock Date</Label>
                <Input
                  id="update-date"
                  type="date"
                  value={new Date().toISOString().split('T')[0]}
                  onChange={(e) => setSelectedItem({ ...selectedItem, lastRestocked: e.target.value })}
                  className="col-span-3"
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsUpdateDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleUpdateItem}>Save Changes</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Inventory;
