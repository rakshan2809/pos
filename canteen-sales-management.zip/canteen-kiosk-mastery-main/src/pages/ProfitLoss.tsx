import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Separator } from '@/components/ui/separator';
import { 
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  ComposedChart,
  Area
} from 'recharts';
import { Calendar, Download, TrendingUp, TrendingDown, DollarSign } from 'lucide-react';
import { 
  mockSales, 
  getSalesForDateRange,
  calculateSaleProfit,
  getTotalExpenses,
  employees
} from '@/data/canteenData';

const ProfitLoss = () => {
  const [period, setPeriod] = useState('month');
  const [startDate, setStartDate] = useState(() => {
    const d = new Date();
    d.setDate(1); // First day of current month
    return d.toISOString().split('T')[0];
  });
  const [endDate, setEndDate] = useState(new Date().toISOString().split('T')[0]);
  const [plData, setPLData] = useState({
    totalRevenue: 0,
    totalCogs: 0,
    grossProfit: 0,
    grossMargin: 0,
    expenses: {
      salaries: 0,
      rent: 0,
      utilities: 0,
      other: 0,
    },
    totalExpenses: 0,
    netProfit: 0,
    netMargin: 0,
  });
  const [monthlyData, setMonthlyData] = useState<any[]>([]);
  
  useEffect(() => {
    let calculatedStartDate = new Date(startDate);
    const calculatedEndDate = new Date(endDate);
    
    if (period === 'month') {
      calculatedStartDate = new Date(calculatedEndDate.getFullYear(), calculatedEndDate.getMonth(), 1);
      setStartDate(calculatedStartDate.toISOString().split('T')[0]);
    } else if (period === 'quarter') {
      const quarter = Math.floor(calculatedEndDate.getMonth() / 3);
      calculatedStartDate = new Date(calculatedEndDate.getFullYear(), quarter * 3, 1);
      setStartDate(calculatedStartDate.toISOString().split('T')[0]);
    } else if (period === 'year') {
      calculatedStartDate = new Date(calculatedEndDate.getFullYear(), 0, 1);
      setStartDate(calculatedStartDate.toISOString().split('T')[0]);
    }
    
    const filteredSales = getSalesForDateRange(
      calculatedStartDate.toISOString(), 
      calculatedEndDate.toISOString()
    );
    
    const totalRevenue = filteredSales.reduce((sum, sale) => sum + sale.total, 0);
    const totalCogs = filteredSales.reduce((sum, sale) => {
      return sum + (sale.total - calculateSaleProfit(sale));
    }, 0);
    
    const grossProfit = totalRevenue - totalCogs;
    const grossMargin = totalRevenue > 0 ? (grossProfit / totalRevenue) * 100 : 0;
    
    const daysDiff = Math.max(1, Math.ceil((calculatedEndDate.getTime() - calculatedStartDate.getTime()) / (1000 * 60 * 60 * 24)));
    
    const monthlySalaries = employees.reduce((sum, employee) => sum + employee.salary, 0);
    const salaries = monthlySalaries * (daysDiff / 30);
    
    const rent = 15000 * (daysDiff / 30);
    const utilities = 8000 * (daysDiff / 30);
    const other = 5000 * (daysDiff / 30);
    
    const totalExpenses = salaries + rent + utilities + other;
    
    const netProfit = grossProfit - totalExpenses;
    const netMargin = totalRevenue > 0 ? (netProfit / totalRevenue) * 100 : 0;
    
    setPLData({
      totalRevenue,
      totalCogs,
      grossProfit,
      grossMargin,
      expenses: {
        salaries,
        rent,
        utilities,
        other,
      },
      totalExpenses,
      netProfit,
      netMargin,
    });
    
    const months = [];
    const currentDate = new Date(calculatedEndDate);
    currentDate.setDate(1);
    
    for (let i = 0; i < 6; i++) {
      const monthDate = new Date(currentDate);
      monthDate.setMonth(monthDate.getMonth() - i);
      
      const monthStart = new Date(monthDate.getFullYear(), monthDate.getMonth(), 1);
      const monthEnd = new Date(monthDate.getFullYear(), monthDate.getMonth() + 1, 0);
      
      const monthSales = getSalesForDateRange(
        monthStart.toISOString(), 
        monthEnd.toISOString()
      );
      
      const monthRevenue = monthSales.reduce((sum, sale) => sum + sale.total, 0);
      const monthCogs = monthSales.reduce((sum, sale) => {
        return sum + (sale.total - calculateSaleProfit(sale));
      }, 0);
      
      const monthGrossProfit = monthRevenue - monthCogs;
      
      const daysInMonth = monthEnd.getDate();
      const monthSalaries = monthlySalaries;
      const monthTotalExpenses = monthSalaries + rent + utilities + other;
      
      const monthNetProfit = monthGrossProfit - monthTotalExpenses;
      
      months.push({
        name: monthDate.toLocaleDateString('en-US', { month: 'short', year: 'numeric' }),
        revenue: monthRevenue,
        expenses: monthTotalExpenses,
        profit: monthNetProfit,
        grossProfit: monthGrossProfit,
      });
    }
    
    setMonthlyData(months.reverse());
  }, [period, endDate]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Profit & Loss</h1>
          <p className="text-gray-500">Financial performance analysis</p>
        </div>
        <div className="flex items-center space-x-2 mt-4 md:mt-0">
          <Button variant="outline" size="sm">
            <Download className="mr-2 h-4 w-4" />
            Export Report
          </Button>
        </div>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Report Period</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-3">
            <div>
              <Tabs value={period} onValueChange={setPeriod}>
                <TabsList className="w-full">
                  <TabsTrigger value="month">Month</TabsTrigger>
                  <TabsTrigger value="quarter">Quarter</TabsTrigger>
                  <TabsTrigger value="year">Year</TabsTrigger>
                  <TabsTrigger value="custom">Custom</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
            
            {period === 'custom' && (
              <>
                <div className="flex items-center space-x-2">
                  <Calendar className="h-4 w-4 text-gray-500" />
                  <Input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <Calendar className="h-4 w-4 text-gray-500" />
                  <Input
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                  />
                </div>
              </>
            )}
            
            {period !== 'custom' && (
              <div className="flex items-center space-x-2 md:col-span-2">
                <Calendar className="h-4 w-4 text-gray-500" />
                <Input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  placeholder="End Date"
                />
              </div>
            )}
          </div>
        </CardContent>
      </Card>
      
      <div className="grid gap-4 md:grid-cols-4">
        <Card className={`${plData.netProfit >= 0 ? 'border-green-500' : 'border-red-500'} border-l-4`}>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Net Profit</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <div className={`text-2xl font-bold ${plData.netProfit >= 0 ? 'text-green-500' : 'text-red-500'}`}>
                ₹{Math.abs(plData.netProfit).toFixed(2)}
              </div>
              {plData.netProfit >= 0 ? (
                <TrendingUp className="ml-2 h-4 w-4 text-green-500" />
              ) : (
                <TrendingDown className="ml-2 h-4 w-4 text-red-500" />
              )}
            </div>
            <p className="text-xs text-gray-500 mt-1">Net Margin: {plData.netMargin.toFixed(2)}%</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹{plData.totalRevenue.toFixed(2)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Gross Profit</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹{plData.grossProfit.toFixed(2)}</div>
            <p className="text-xs text-gray-500 mt-1">Margin: {plData.grossMargin.toFixed(2)}%</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Expenses</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">₹{plData.totalExpenses.toFixed(2)}</div>
          </CardContent>
        </Card>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle>Profit & Loss Statement</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div>
              <h3 className="font-medium">Revenue</h3>
              <div className="mt-2 space-y-2">
                <div className="flex justify-between py-1">
                  <span>Sales Revenue</span>
                  <span>₹{plData.totalRevenue.toFixed(2)}</span>
                </div>
                <Separator />
                <div className="flex justify-between py-1 font-medium">
                  <span>Total Revenue</span>
                  <span>₹{plData.totalRevenue.toFixed(2)}</span>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="font-medium">Cost of Goods Sold</h3>
              <div className="mt-2 space-y-2">
                <div className="flex justify-between py-1">
                  <span>Cost of Goods Sold</span>
                  <span>₹{plData.totalCogs.toFixed(2)}</span>
                </div>
                <Separator />
                <div className="flex justify-between py-1 font-medium">
                  <span>Gross Profit</span>
                  <span>₹{plData.grossProfit.toFixed(2)}</span>
                </div>
                <div className="flex justify-between py-1 text-sm text-gray-500">
                  <span>Gross Profit Margin</span>
                  <span>{plData.grossMargin.toFixed(2)}%</span>
                </div>
              </div>
            </div>
            
            <div>
              <h3 className="font-medium">Expenses</h3>
              <div className="mt-2 space-y-2">
                <div className="flex justify-between py-1">
                  <span>Salaries & Wages</span>
                  <span>₹{plData.expenses.salaries.toFixed(2)}</span>
                </div>
                <div className="flex justify-between py-1">
                  <span>Rent</span>
                  <span>₹{plData.expenses.rent.toFixed(2)}</span>
                </div>
                <div className="flex justify-between py-1">
                  <span>Utilities</span>
                  <span>₹{plData.expenses.utilities.toFixed(2)}</span>
                </div>
                <div className="flex justify-between py-1">
                  <span>Other Expenses</span>
                  <span>₹{plData.expenses.other.toFixed(2)}</span>
                </div>
                <Separator />
                <div className="flex justify-between py-1 font-medium">
                  <span>Total Expenses</span>
                  <span>₹{plData.totalExpenses.toFixed(2)}</span>
                </div>
              </div>
            </div>
            
            <div>
              <Separator className="my-2" />
              <div className="flex justify-between py-1 font-bold text-lg">
                <span>Net Profit</span>
                <span className={plData.netProfit >= 0 ? 'text-green-500' : 'text-red-500'}>
                  ₹{plData.netProfit.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between py-1 text-sm text-gray-500">
                <span>Net Profit Margin</span>
                <span>{plData.netMargin.toFixed(2)}%</span>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Monthly Trends</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[400px]">
            <ResponsiveContainer width="100%" height="100%">
              <ComposedChart data={monthlyData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip formatter={(value: number) => [`₹${value.toFixed(2)}`, '']} />
                <Legend />
                <Bar dataKey="revenue" name="Revenue" fill="#F97316" />
                <Bar dataKey="expenses" name="Expenses" fill="#3B82F6" />
                <Line type="monotone" dataKey="profit" name="Net Profit" stroke="#10B981" strokeWidth={2} />
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Revenue vs Expenses Breakdown</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={[
                  { name: 'Revenue', value: plData.totalRevenue },
                  { name: 'COGS', value: plData.totalCogs },
                  { name: 'Gross Profit', value: plData.grossProfit },
                  { name: 'Expenses', value: plData.totalExpenses },
                  { name: 'Net Profit', value: plData.netProfit },
                ]}
                margin={{ top: 20, right: 30, left: 20, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip formatter={(value: number) => [`₹${value.toFixed(2)}`, '']} />
                <Bar dataKey="value" name="Amount" fill="#F97316" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ProfitLoss;
