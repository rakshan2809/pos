
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { 
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';
import { Calendar, Download, FileText, Filter, Printer } from 'lucide-react';
import { useToast } from "@/hooks/use-toast";
import { 
  mockSales, 
  menuItems, 
  getSalesForDate, 
  getSalesForDateRange,
  getSalesStats,
  calculateSaleProfit
} from '@/data/canteenData';

const Reports = () => {
  const { toast } = useToast();
  const [reportType, setReportType] = useState('daily');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [startDate, setStartDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() - 30);
    return d.toISOString().split('T')[0];
  });
  const [endDate, setEndDate] = useState(new Date().toISOString().split('T')[0]);
  const [reportData, setReportData] = useState<any[]>([]);
  const [summaryData, setSummaryData] = useState({
    totalSales: 0,
    totalRevenue: 0,
    totalProfit: 0,
    averageOrderValue: 0,
  });
  const [topItems, setTopItems] = useState<{ name: string; quantity: number; revenue: number }[]>([]);
  const [isReportGenerated, setIsReportGenerated] = useState(false);
  
  const generateReport = () => {
    let filteredSales;
    
    if (reportType === 'daily') {
      filteredSales = getSalesForDate(date);
    } else {
      filteredSales = getSalesForDateRange(startDate, endDate);
    }
    
    // Process sales for report
    const processedData = filteredSales.map(sale => {
      const items = sale.items.map(item => {
        const menuItem = menuItems.find(m => m.id === item.menuItemId);
        return {
          name: menuItem ? menuItem.name : `Item #${item.menuItemId}`,
          price: item.price,
          quantity: item.quantity,
          subtotal: item.price * item.quantity,
        };
      });
      
      return {
        id: sale.id,
        timestamp: new Date(sale.timestamp).toLocaleString(),
        items,
        total: sale.total,
        profit: calculateSaleProfit(sale),
      };
    });
    
    setReportData(processedData);
    
    // Calculate summary data
    const { totalSales, totalRevenue, totalProfit } = getSalesStats(filteredSales);
    const averageOrderValue = totalSales > 0 ? totalRevenue / totalSales : 0;
    
    setSummaryData({
      totalSales,
      totalRevenue,
      totalProfit,
      averageOrderValue,
    });
    
    // Calculate top items
    const itemMap = new Map<number, { quantity: number; revenue: number }>();
    
    filteredSales.forEach(sale => {
      sale.items.forEach(item => {
        const current = itemMap.get(item.menuItemId) || { quantity: 0, revenue: 0 };
        itemMap.set(item.menuItemId, {
          quantity: current.quantity + item.quantity,
          revenue: current.revenue + (item.price * item.quantity),
        });
      });
    });
    
    const topItemsData = Array.from(itemMap.entries())
      .map(([id, data]) => {
        const menuItem = menuItems.find(m => m.id === id);
        return {
          name: menuItem ? menuItem.name : `Item #${id}`,
          quantity: data.quantity,
          revenue: data.revenue,
        };
      })
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 10);
    
    setTopItems(topItemsData);
    setIsReportGenerated(true);
    
    // Show toast notification
    toast({
      title: "Report Generated",
      description: `${reportType === 'daily' ? 'Daily' : 'Custom'} report generated successfully.`,
    });
  };

  // No longer auto-generate report on date/type change
  useEffect(() => {
    // Reset the report generated flag when changing report parameters
    setIsReportGenerated(false);
  }, [reportType, date, startDate, endDate]);

  // Function to handle printing the report
  const handlePrint = () => {
    toast({
      title: "Printing Report",
      description: "Sending report to printer...",
    });
    
    setTimeout(() => {
      window.print();
    }, 500);
  };

  // Function to handle exporting the report as CSV
  const handleExport = () => {
    if (!isReportGenerated || reportData.length === 0) {
      toast({
        title: "Export Failed",
        description: "No report data to export.",
        variant: "destructive",
      });
      return;
    }

    // Create CSV content
    let csvContent = "data:text/csv;charset=utf-8,";
    
    // Add headers
    csvContent += "Transaction ID,Date & Time,Items,Total,Profit\n";
    
    // Add data rows
    reportData.forEach(sale => {
      const items = sale.items.map(item => `${item.name} x ${item.quantity}`).join('; ');
      const row = [
        sale.id,
        sale.timestamp,
        `"${items}"`, // Wrap in quotes to handle commas in the items list
        sale.total.toFixed(2),
        sale.profit.toFixed(2)
      ];
      csvContent += row.join(',') + '\n';
    });
    
    // Create a download link and trigger it
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `canteen-report-${new Date().toISOString().slice(0, 10)}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    toast({
      title: "Export Successful",
      description: "Report has been exported as CSV.",
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Reports</h1>
          <p className="text-gray-500">View sales and revenue reports</p>
        </div>
        <div className="flex items-center space-x-2 mt-4 md:mt-0">
          <Button variant="outline" size="sm"
            disabled={!isReportGenerated}
            onClick={handlePrint}>
            <Printer className="mr-2 h-4 w-4" />
            Print
          </Button>
          <Button variant="outline" size="sm"
            disabled={!isReportGenerated}
            onClick={handleExport}>
            <Download className="mr-2 h-4 w-4" />
            Export
          </Button>
        </div>
      </div>
      
      {/* Report configuration */}
      <Card>
        <CardHeader>
          <CardTitle>Report Settings</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-4">
            <div>
              <Tabs value={reportType} onValueChange={setReportType}>
                <TabsList className="w-full">
                  <TabsTrigger value="daily">Daily</TabsTrigger>
                  <TabsTrigger value="custom">Date Range</TabsTrigger>
                </TabsList>
              </Tabs>
            </div>
            
            {reportType === 'daily' ? (
              <div className="flex items-center space-x-2">
                <Calendar className="h-4 w-4 text-gray-500" />
                <Input
                  type="date"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                />
              </div>
            ) : (
              <>
                <div className="flex items-center space-x-2">
                  <Calendar className="h-4 w-4 text-gray-500" />
                  <Input
                    type="date"
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <Calendar className="h-4 w-4 text-gray-500" />
                  <Input
                    type="date"
                    value={endDate}
                    onChange={(e) => setEndDate(e.target.value)}
                  />
                </div>
              </>
            )}
            
            <div>
              <Button className="w-full" onClick={generateReport}>
                <Filter className="mr-2 h-4 w-4" />
                Generate Report
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
      
      {/* Only show report content when a report has been generated */}
      {isReportGenerated ? (
        <>
          {/* Summary cards */}
          <div className="grid gap-4 md:grid-cols-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total Transactions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{summaryData.totalSales}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total Revenue</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">₹{summaryData.totalRevenue.toFixed(2)}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Total Profit</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">₹{summaryData.totalProfit.toFixed(2)}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Average Order Value</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">₹{summaryData.averageOrderValue.toFixed(2)}</div>
              </CardContent>
            </Card>
          </div>
          
          {/* Top selling items chart */}
          <Card>
            <CardHeader>
              <CardTitle>Top Selling Items</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={topItems} layout="vertical">
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" />
                    <YAxis
                      dataKey="name"
                      type="category"
                      width={150}
                      tick={{ fontSize: 12 }}
                    />
                    <Tooltip
                      formatter={(value: number, name: string) => [
                        name === 'revenue' ? `₹${value.toFixed(2)}` : value,
                        name === 'revenue' ? 'Revenue' : 'Quantity'
                      ]}
                    />
                    <Legend />
                    <Bar dataKey="revenue" fill="#F97316" name="Revenue" />
                    <Bar dataKey="quantity" fill="#3B82F6" name="Quantity" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </CardContent>
          </Card>
          
          {/* Detailed report table */}
          <Card>
            <CardHeader>
              <CardTitle>Detailed Sales Report</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="border rounded-lg overflow-hidden">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Transaction ID</TableHead>
                      <TableHead>Date & Time</TableHead>
                      <TableHead>Items</TableHead>
                      <TableHead className="text-right">Total</TableHead>
                      <TableHead className="text-right">Profit</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {reportData.map((sale) => (
                      <TableRow key={sale.id}>
                        <TableCell>{sale.id}</TableCell>
                        <TableCell>{sale.timestamp}</TableCell>
                        <TableCell>
                          <div className="space-y-1">
                            {sale.items.map((item, idx) => (
                              <div key={idx} className="text-sm">
                                {item.name} × {item.quantity}
                              </div>
                            ))}
                          </div>
                        </TableCell>
                        <TableCell className="text-right">₹{sale.total.toFixed(2)}</TableCell>
                        <TableCell className="text-right">₹{sale.profit.toFixed(2)}</TableCell>
                      </TableRow>
                    ))}
                    
                    {reportData.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center h-24">
                          <div className="flex flex-col items-center justify-center text-gray-500">
                            <FileText className="h-8 w-8 mb-2" />
                            <p>No sales data found for the selected period</p>
                          </div>
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </>
      ) : (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-10">
            <FileText className="h-16 w-16 text-gray-300 mb-4" />
            <h3 className="text-xl font-medium mb-2">No Report Generated</h3>
            <p className="text-gray-500 text-center mb-6">
              Select your report parameters and click "Generate Report" to view the data.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default Reports;
