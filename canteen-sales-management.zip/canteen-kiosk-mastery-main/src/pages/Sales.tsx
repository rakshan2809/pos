import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';
import { Plus, Minus, ShoppingCart, Search, Tag, X, Edit, Save, Trash2 } from 'lucide-react';
import { menuItems, MenuItem } from '@/data/canteenData';
import { nanoid } from 'nanoid';
import { useAuth } from '@/contexts/AuthContext';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogFooter,
  DialogTrigger
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { 
  Form, 
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from '@/components/ui/form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import * as z from 'zod';

interface CartItem {
  id: string;
  menuItem: MenuItem;
  quantity: number;
}

const productSchema = z.object({
  name: z.string().min(2, { message: "Name must be at least 2 characters" }),
  price: z.coerce.number().min(1, { message: "Price must be at least 1" }),
  category: z.string().min(1, { message: "Category is required" }),
  cost: z.coerce.number().min(0, { message: "Cost must be a positive number" }),
  inStock: z.boolean().default(true)
});

const Sales = () => {
  const { user } = useAuth();
  const [cart, setCart] = useState<CartItem[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');
  const [activeTab, setActiveTab] = useState('sales');
  const [products, setProducts] = useState<MenuItem[]>(menuItems);
  const [editProduct, setEditProduct] = useState<MenuItem | null>(null);
  const [deleteConfirmOpen, setDeleteConfirmOpen] = useState(false);
  const [productToDelete, setProductToDelete] = useState<number | null>(null);
  
  const form = useForm<z.infer<typeof productSchema>>({
    resolver: zodResolver(productSchema),
    defaultValues: {
      name: '',
      price: 0,
      category: '',
      cost: 0,
      inStock: true
    }
  });
  
  useEffect(() => {
    if (editProduct) {
      form.reset({
        name: editProduct.name,
        price: editProduct.price,
        category: editProduct.category,
        cost: editProduct.cost,
        inStock: editProduct.inStock
      });
    } else {
      form.reset({
        name: '',
        price: 0,
        category: '',
        cost: 0,
        inStock: true
      });
    }
  }, [editProduct, form]);
  
  const cartTotal = cart.reduce((sum, item) => sum + (item.menuItem.price * item.quantity), 0);
  
  const categories = ['All', ...Array.from(new Set(products.map(item => item.category)))];
  
  const filteredItems = products.filter(item => {
    const matchesSearch = item.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = activeCategory === 'All' || item.category === activeCategory;
    return matchesSearch && matchesCategory;
  });
  
  const addToCart = (menuItem: MenuItem) => {
    setCart(prevCart => {
      const existingItemIndex = prevCart.findIndex(item => item.menuItem.id === menuItem.id);
      
      if (existingItemIndex >= 0) {
        const updatedCart = [...prevCart];
        updatedCart[existingItemIndex].quantity += 1;
        return updatedCart;
      } else {
        return [...prevCart, { id: nanoid(), menuItem, quantity: 1 }];
      }
    });
    
    toast.success(`Added ${menuItem.name} to cart`);
  };
  
  const removeFromCart = (cartItemId: string) => {
    setCart(prevCart => prevCart.filter(item => item.id !== cartItemId));
  };
  
  const updateQuantity = (cartItemId: string, newQuantity: number) => {
    if (newQuantity < 1) return;
    
    setCart(prevCart => 
      prevCart.map(item => 
        item.id === cartItemId 
          ? { ...item, quantity: newQuantity } 
          : item
      )
    );
  };
  
  const clearCart = () => {
    setCart([]);
    toast.info('Cart cleared');
  };
  
  const processPayment = () => {
    if (cart.length === 0) {
      toast.error('Cart is empty');
      return;
    }
    
    toast.success('Payment processed successfully!');
    
    setCart([]);
  };
  
  const handleAddProduct = (data: z.infer<typeof productSchema>) => {
    const newProduct: MenuItem = {
      id: Math.max(...products.map(p => p.id)) + 1,
      name: data.name,
      price: data.price,
      category: data.category,
      cost: data.cost,
      inStock: data.inStock
    };
    
    setProducts([...products, newProduct]);
    toast.success(`Product "${data.name}" added successfully`);
    form.reset();
  };
  
  const handleUpdateProduct = (data: z.infer<typeof productSchema>) => {
    if (!editProduct) return;
    
    const updatedProducts = products.map(product => 
      product.id === editProduct.id 
        ? { ...product, ...data } 
        : product
    );
    
    setProducts(updatedProducts);
    setEditProduct(null);
    toast.success(`Product "${data.name}" updated successfully`);
  };
  
  const handleDeleteProduct = (id: number) => {
    setProducts(products.filter(product => product.id !== id));
    setProductToDelete(null);
    setDeleteConfirmOpen(false);
    toast.success('Product deleted successfully');
  };
  
  const onSubmit = (data: z.infer<typeof productSchema>) => {
    if (editProduct) {
      handleUpdateProduct(data);
    } else {
      handleAddProduct(data);
    }
  };

  return (
    <div className="h-full flex flex-col">
      <div className="mb-6">
        <h1 className="text-3xl font-bold tracking-tight">Sales Terminal</h1>
        <p className="text-gray-500">Process customer orders and payments</p>
      </div>
      
      <Tabs 
        value={activeTab} 
        onValueChange={setActiveTab} 
        className="flex-1 flex flex-col"
      >
        <TabsList className="justify-start mb-6">
          <TabsTrigger value="sales">Sales Terminal</TabsTrigger>
          <TabsTrigger value="products">Manage Products</TabsTrigger>
        </TabsList>
        
        <TabsContent value="sales" className="flex-1 flex flex-col">
          <div className="grid gap-6 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4 md:gap-8 flex-1">
            <div className="md:col-span-2 xl:col-span-3 flex flex-col">
              <div className="flex flex-col sm:flex-row gap-4 mb-4">
                <div className="relative flex-1">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500" />
                  <Input
                    type="search"
                    placeholder="Search items..."
                    className="pl-8"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <div className="flex-1">
                  <Tabs value={activeCategory} onValueChange={setActiveCategory}>
                    <ScrollArea className="w-full whitespace-nowrap">
                      <TabsList className="w-full justify-start">
                        {categories.map(category => (
                          <TabsTrigger key={category} value={category}>
                            {category}
                          </TabsTrigger>
                        ))}
                      </TabsList>
                    </ScrollArea>
                  </Tabs>
                </div>
              </div>
              
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 overflow-y-auto pb-4">
                {filteredItems.map(item => (
                  <Card 
                    key={item.id} 
                    className="cursor-pointer hover:shadow-md transition-shadow"
                    onClick={() => addToCart(item)}
                  >
                    <CardContent className="p-4">
                      <div className="text-sm font-medium line-clamp-2 h-10">{item.name}</div>
                      <div className="mt-2 flex items-center justify-between">
                        <span className="text-lg font-bold">₹{item.price}</span>
                        <Badge variant="outline" className="text-xs">
                          {item.category}
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                ))}
                
                {filteredItems.length === 0 && (
                  <div className="col-span-full text-center py-8 text-gray-500">
                    No items found. Try a different search term or category.
                  </div>
                )}
              </div>
            </div>
            
            <div className="flex flex-col border rounded-lg">
              <div className="p-4 border-b">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <ShoppingCart className="h-5 w-5 mr-2 text-gray-500" />
                    <h2 className="text-lg font-semibold">Current Order</h2>
                  </div>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={clearCart}
                    disabled={cart.length === 0}
                  >
                    Clear
                  </Button>
                </div>
              </div>
              
              <ScrollArea className="flex-1 p-4">
                {cart.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    Cart is empty. Add items to get started.
                  </div>
                ) : (
                  <div className="space-y-4">
                    {cart.map(item => (
                      <div key={item.id} className="flex items-center justify-between">
                        <div className="flex-1">
                          <div className="font-medium">{item.menuItem.name}</div>
                          <div className="text-sm text-gray-500">₹{item.menuItem.price} each</div>
                        </div>
                        <div className="flex items-center gap-2">
                          <Button 
                            variant="outline" 
                            size="icon" 
                            className="h-6 w-6"
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                          >
                            <Minus className="h-3 w-3" />
                          </Button>
                          <span className="w-6 text-center">{item.quantity}</span>
                          <Button 
                            variant="outline" 
                            size="icon" 
                            className="h-6 w-6"
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                          >
                            <Plus className="h-3 w-3" />
                          </Button>
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-6 w-6 text-gray-500"
                            onClick={() => removeFromCart(item.id)}
                          >
                            <X className="h-3 w-3" />
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </ScrollArea>
              
              <div className="p-4 border-t bg-gray-50">
                <div className="space-y-1.5 mb-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Subtotal</span>
                    <span>₹{cartTotal.toFixed(2)}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm">Tax (5%)</span>
                    <span>₹{(cartTotal * 0.05).toFixed(2)}</span>
                  </div>
                  <Separator className="my-2" />
                  <div className="flex items-center justify-between font-bold">
                    <span>Total</span>
                    <span>₹{(cartTotal * 1.05).toFixed(2)}</span>
                  </div>
                </div>
                
                <Button 
                  className="w-full" 
                  size="lg"
                  onClick={processPayment}
                  disabled={cart.length === 0}
                >
                  Process Payment
                </Button>
              </div>
            </div>
          </div>
        </TabsContent>
        
        <TabsContent value="products" className="flex-1">
          <div className="flex justify-between mb-6">
            <h2 className="text-2xl font-bold">Manage Products</h2>
            <Dialog>
              <DialogTrigger asChild>
                <Button onClick={() => setEditProduct(null)}>
                  <Plus className="mr-2 h-4 w-4" /> Add Product
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>{editProduct ? 'Edit Product' : 'Add New Product'}</DialogTitle>
                </DialogHeader>
                
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Product Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter product name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="price"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Price (₹)</FormLabel>
                            <FormControl>
                              <Input type="number" min="0" step="0.01" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="cost"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Cost (₹)</FormLabel>
                            <FormControl>
                              <Input type="number" min="0" step="0.01" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={form.control}
                      name="category"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Category</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter category" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={form.control}
                      name="inStock"
                      render={({ field }) => (
                        <FormItem className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4">
                          <FormControl>
                            <input
                              type="checkbox"
                              checked={field.value}
                              onChange={field.onChange}
                              className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
                            />
                          </FormControl>
                          <div className="space-y-1 leading-none">
                            <FormLabel>In Stock</FormLabel>
                          </div>
                        </FormItem>
                      )}
                    />
                    
                    <DialogFooter>
                      <Button type="submit">{editProduct ? 'Update Product' : 'Add Product'}</Button>
                    </DialogFooter>
                  </form>
                </Form>
              </DialogContent>
            </Dialog>
          </div>
          
          <div className="border rounded-md">
            <div className="grid grid-cols-12 font-medium border-b py-3 px-4 bg-gray-50">
              <div className="col-span-1">ID</div>
              <div className="col-span-4">Name</div>
              <div className="col-span-2">Price</div>
              <div className="col-span-2">Category</div>
              <div className="col-span-1 text-center">Status</div>
              <div className="col-span-2 text-right">Actions</div>
            </div>
            <ScrollArea className="h-[calc(100vh-300px)]">
              {products.map(product => (
                <div key={product.id} className="grid grid-cols-12 py-3 px-4 border-b items-center">
                  <div className="col-span-1 text-gray-500">{product.id}</div>
                  <div className="col-span-4 font-medium">{product.name}</div>
                  <div className="col-span-2">₹{product.price}</div>
                  <div className="col-span-2">
                    <Badge variant="outline">{product.category}</Badge>
                  </div>
                  <div className="col-span-1 text-center">
                    <Badge variant="secondary">
                      {product.inStock ? 'In Stock' : 'Out of Stock'}
                    </Badge>
                  </div>
                  <div className="col-span-2 flex justify-end gap-2">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button 
                          variant="outline" 
                          size="icon"
                          onClick={() => setEditProduct(product)}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Edit Product</DialogTitle>
                        </DialogHeader>
                      </DialogContent>
                    </Dialog>
                    
                    <Dialog open={deleteConfirmOpen && productToDelete === product.id} onOpenChange={(open) => {
                      setDeleteConfirmOpen(open);
                      if (!open) setProductToDelete(null);
                    }}>
                      <DialogTrigger asChild>
                        <Button 
                          variant="outline" 
                          size="icon"
                          className="text-destructive"
                          onClick={() => setProductToDelete(product.id)}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Confirm Deletion</DialogTitle>
                        </DialogHeader>
                        <p>Are you sure you want to delete "{product.name}"? This action cannot be undone.</p>
                        <DialogFooter>
                          <Button 
                            variant="outline" 
                            onClick={() => {
                              setDeleteConfirmOpen(false);
                              setProductToDelete(null);
                            }}
                          >
                            Cancel
                          </Button>
                          <Button 
                            variant="destructive" 
                            onClick={() => handleDeleteProduct(product.id)}
                          >
                            Delete
                          </Button>
                        </DialogFooter>
                      </DialogContent>
                    </Dialog>
                  </div>
                </div>
              ))}
            </ScrollArea>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Sales;
