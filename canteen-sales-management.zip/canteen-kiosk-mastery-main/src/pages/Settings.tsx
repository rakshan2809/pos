
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Label } from '@/components/ui/label';
import { Separator } from '@/components/ui/separator';
import { toast } from 'sonner';
import { 
  User, 
  Building, 
  Bell, 
  Settings as SettingsIcon, 
  Save,
  Store
} from 'lucide-react';

const Settings = () => {
  const [shopSettings, setShopSettings] = useState({
    name: 'Dr. Sivanthi Aditanar College Canteen',
    address: 'Dr. Sivanthi Aditanar College of Engineering, Tiruchendur',
    phone: '9876543210',
    email: 'canteen@example.com',
    taxRate: 5,
    currency: '₹',
    receiptFooter: 'Thank you for your purchase!',
  });
  
  const [notificationSettings, setNotificationSettings] = useState({
    lowStockAlert: true,
    dailySalesReport: true,
    orderNotification: true,
  });
  
  const [backupSettings, setBackupSettings] = useState({
    autoBackup: true,
    backupFrequency: 'daily',
    lastBackup: '2023-04-12 09:30:45',
  });
  
  // Save shop settings
  const handleSaveShopSettings = () => {
    toast.success('Shop settings saved successfully');
  };
  
  // Save notification settings
  const handleSaveNotificationSettings = () => {
    toast.success('Notification settings saved successfully');
  };
  
  // Save backup settings
  const handleSaveBackupSettings = () => {
    toast.success('Backup settings saved successfully');
  };
  
  // Trigger manual backup
  const handleManualBackup = () => {
    toast.success('Manual backup initiated');
    setBackupSettings({
      ...backupSettings,
      lastBackup: new Date().toLocaleString(),
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Settings</h1>
          <p className="text-gray-500">Manage system settings and configurations</p>
        </div>
      </div>
      
      <Tabs defaultValue="shop">
        <TabsList>
          <TabsTrigger value="shop">
            <Store className="h-4 w-4 mr-2" />
            Shop
          </TabsTrigger>
          <TabsTrigger value="notifications">
            <Bell className="h-4 w-4 mr-2" />
            Notifications
          </TabsTrigger>
          <TabsTrigger value="backup">
            <SettingsIcon className="h-4 w-4 mr-2" />
            Backup & Restore
          </TabsTrigger>
        </TabsList>
        
        {/* Shop Settings */}
        <TabsContent value="shop">
          <Card>
            <CardHeader>
              <CardTitle>Shop Information</CardTitle>
              <CardDescription>
                Manage your shop details and configuration
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="grid gap-2">
                  <Label htmlFor="shop-name">Shop Name</Label>
                  <Input
                    id="shop-name"
                    value={shopSettings.name}
                    onChange={(e) => setShopSettings({ ...shopSettings, name: e.target.value })}
                  />
                </div>
                
                <div className="grid gap-2">
                  <Label htmlFor="shop-address">Address</Label>
                  <Textarea
                    id="shop-address"
                    value={shopSettings.address}
                    onChange={(e) => setShopSettings({ ...shopSettings, address: e.target.value })}
                  />
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="shop-phone">Phone</Label>
                    <Input
                      id="shop-phone"
                      value={shopSettings.phone}
                      onChange={(e) => setShopSettings({ ...shopSettings, phone: e.target.value })}
                    />
                  </div>
                  
                  <div className="grid gap-2">
                    <Label htmlFor="shop-email">Email</Label>
                    <Input
                      id="shop-email"
                      type="email"
                      value={shopSettings.email}
                      onChange={(e) => setShopSettings({ ...shopSettings, email: e.target.value })}
                    />
                  </div>
                </div>
              </div>
              
              <Separator />
              
              <div className="space-y-4">
                <h3 className="text-lg font-medium">Receipt & Payment Settings</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <Label htmlFor="tax-rate">Tax Rate (%)</Label>
                    <Input
                      id="tax-rate"
                      type="number"
                      value={shopSettings.taxRate}
                      onChange={(e) => setShopSettings({ ...shopSettings, taxRate: Number(e.target.value) })}
                    />
                  </div>
                  
                  <div className="grid gap-2">
                    <Label htmlFor="currency">Currency Symbol</Label>
                    <Input
                      id="currency"
                      value={shopSettings.currency}
                      onChange={(e) => setShopSettings({ ...shopSettings, currency: e.target.value })}
                    />
                  </div>
                </div>
                
                <div className="grid gap-2">
                  <Label htmlFor="receipt-footer">Receipt Footer Text</Label>
                  <Textarea
                    id="receipt-footer"
                    value={shopSettings.receiptFooter}
                    onChange={(e) => setShopSettings({ ...shopSettings, receiptFooter: e.target.value })}
                  />
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={handleSaveShopSettings}>
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        {/* Notification Settings */}
        <TabsContent value="notifications">
          <Card>
            <CardHeader>
              <CardTitle>Notification Settings</CardTitle>
              <CardDescription>
                Configure when and how you receive notifications
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Low Stock Alerts</Label>
                    <p className="text-sm text-gray-500">
                      Receive alerts when inventory items are running low
                    </p>
                  </div>
                  <Switch
                    checked={notificationSettings.lowStockAlert}
                    onCheckedChange={(checked) => 
                      setNotificationSettings({ ...notificationSettings, lowStockAlert: checked })
                    }
                  />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Daily Sales Report</Label>
                    <p className="text-sm text-gray-500">
                      Receive daily sales and revenue reports
                    </p>
                  </div>
                  <Switch
                    checked={notificationSettings.dailySalesReport}
                    onCheckedChange={(checked) => 
                      setNotificationSettings({ ...notificationSettings, dailySalesReport: checked })
                    }
                  />
                </div>
                
                <Separator />
                
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <Label>Order Notifications</Label>
                    <p className="text-sm text-gray-500">
                      Receive notifications for new orders
                    </p>
                  </div>
                  <Switch
                    checked={notificationSettings.orderNotification}
                    onCheckedChange={(checked) => 
                      setNotificationSettings({ ...notificationSettings, orderNotification: checked })
                    }
                  />
                </div>
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={handleSaveNotificationSettings}>
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
        
        {/* Backup & Restore Settings */}
        <TabsContent value="backup">
          <Card>
            <CardHeader>
              <CardTitle>Backup & Restore</CardTitle>
              <CardDescription>
                Configure automatic backups and restore your data
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Automatic Backup</Label>
                  <p className="text-sm text-gray-500">
                    Enable automatic data backups
                  </p>
                </div>
                <Switch
                  checked={backupSettings.autoBackup}
                  onCheckedChange={(checked) => 
                    setBackupSettings({ ...backupSettings, autoBackup: checked })
                  }
                />
              </div>
              
              <div className="grid gap-2">
                <Label htmlFor="backup-frequency">Backup Frequency</Label>
                <select
                  id="backup-frequency"
                  className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
                  value={backupSettings.backupFrequency}
                  onChange={(e) => setBackupSettings({ ...backupSettings, backupFrequency: e.target.value })}
                  disabled={!backupSettings.autoBackup}
                >
                  <option value="daily">Daily</option>
                  <option value="weekly">Weekly</option>
                  <option value="monthly">Monthly</option>
                </select>
              </div>
              
              <div className="grid gap-2">
                <Label>Last Backup</Label>
                <div className="text-sm">{backupSettings.lastBackup}</div>
              </div>
              
              <div className="flex flex-col space-y-2">
                <Button onClick={handleManualBackup}>
                  Backup Now
                </Button>
                
                <Button variant="outline">
                  Restore Data
                </Button>
              </div>
            </CardContent>
            <CardFooter>
              <Button onClick={handleSaveBackupSettings}>
                <Save className="mr-2 h-4 w-4" />
                Save Changes
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Settings;
